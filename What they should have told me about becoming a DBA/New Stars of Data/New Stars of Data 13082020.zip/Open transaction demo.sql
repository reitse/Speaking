begin transaction

-- you've got me!

select top 100 *
from F1.dbo.F1_points_per_race